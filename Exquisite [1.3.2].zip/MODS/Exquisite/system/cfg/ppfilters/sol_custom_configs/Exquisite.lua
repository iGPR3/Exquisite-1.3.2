-- this is called every time AC is started
function init_sol_custom_config()

	-- reset customs to default
	ac.resetGodraysCustomColor()
	ac.resetGodraysCustomDirection()
	ac.resetWeatherStaticAmbient()
	ac.resetShadowsResolution()
	ac.resetShadowsSplits()
	ac.resetSpecularColor()
	ac.resetHorizonFogMultiplier()
	ac.resetGlowBrightness()
	ac.resetWeatherLightsMultiplier()
	ac.resetEmissiveMultiplier()

	SOL__set_config("performance", "sol__use_cpu_split", true)

	SOL__set_config("monitor_compensation", "colors_whitebalance", 1)

	SOL__set_config("pp", "brightness_sun_link_only_interior", false)

	SOL__set_config("csp", "controlled_by_sol", false)

	SOL__set_config("weather", "HDR_multiplier", 1.25)

	SOL__set_config("sky", "blue_preset", 2)
	SOL__set_config("sky", "blue_strenght", 0.99)
	SOL__set_config("sky", "day__horizon_glow", 1.73)
	SOL__set_config("sky", "night__horizon_glow", 1.57)

	SOL__set_config("clouds", "opacity_multiplier", 0.7)
	SOL__set_config("clouds", "render_limiter", 1)

	SOL__set_config("sun", "size", 1.56)
	SOL__set_config("sun", "sky_bloom", 0.73)
	SOL__set_config("sun", "fog_bloom", 1.12)
	
    SOL__set_config("sun", "dazzle_mix", 0.15)
    SOL__set_config("sun", "dazzle_strenght", 0.57)

    SOL__set_config("night", "moonlight_multiplier", 2.2)
    SOL__set_config("night", "starlight_multiplier", 2.23)

    SOL__set_config("gfx", "reflections_brightness", 1.83)
    SOL__set_config("gfx", "reflections_saturation", 0.9)

    SOL__set_config("sound", "wind_volume_interior", 0.4)
    SOL__set_config("sound", "wind_volume_exterior", 1.8)
    SOL__set_config("sound", "thunder_volume_interior", 0.5)
	
end


-- this is called every frame
function update_sol_custom_config(dt)

    ac.setGodraysLength(math.lerp(10, 0, night_compensate(0)))

end




















--   N E R D - O P T I O N S

--!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
--!! 
--!! I will not give any support for this
--!! Change this to your own needs, if you like to play with the core values of Sol
--!!
--!! I put this in, because i also like to play, BUT NO SUPPORT from me for this....
--!!
--!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

-- ▌   NERD SKY   ▐   
-- #
nerd__sky_adjust = {
	
Hue = 0.57 , --min=0,max=2,default=1.00
Saturation = 1.0, --min=0,max=2,default=1.00
Level = 1.20 , --min=0,max=10,default=1.00

SunIntensityFactor = 1.20, --min=0,max=10,default=1.00

AnisotropicIntensity = 1.00, --min=0,max=10,default=1.00
Density = 1.0 , --min=0,max=10,default=1.00

Scale = 1.00, --min=0,max=10,default=1.00
GradientStyle = 1.00, --min=0.2,max=5,default=1.00
InputYOffset = 0.00, --min=-2,max=2,default=0.00
}

--<br>

-- ▌   NERD SUN   ▐   
-- #
nerd__sun_adjust = {
	
-- light source
ls_Hue = 0.75, --min=0,max=2,default=1.00
ls_Saturation = 1.37, --min=0,max=10,default=1.00
ls_Level = 0.75, --min=0,max=10,default=1.00

-- appearance
ap_Level = 1.00, --min=0,max=10,default=1.00
}

-----------------------------------------------------------------------------------
-- NERD SPECULARS
-- #
nerd__speculars_adjust = {

Level = 1.00, --min=0,max=10,default=1.00
}

--<br>

-- ▌   NERD CLOUDS   ▐   
-- #
nerd__clouds_adjust = {
	
Saturation = 1.05, --min=0,max=10,default=1.00
Saturation_limit = 1.1, --min=0,max=2,default=0.90
Lit = 1.45, --min=0,max=10,default=1.00
Contour = 1.50, --min=0,max=10,default=1.00
}

--<br>

-- ▌   NERD AMBIENT   ▐   
-- #
nerd__ambient_adjust = {
	
Hue = 0.75, --min=0,max=2,default=1.00
Saturation = 0.72, --min=0,max=10,default=1.00
Level = 1.18, --min=0,max=10,default=1.00
}

-- #
nerd__directional_ambient_light = {

Level = 1.00, --min=0,max=10,default=1.00
}

nerd__overcast_sky_ambient_light = {

Level = 1.00, --min=0,max=10,default=1.00
}

--<br>

-- ▌   NERD FOG   ▐   
-- #
nerd__fog_use_custom_distant_fog = false --default=false

-- #
nerd__fog_custom_distant_fog = {

distance = 30000, --min=1000,max=50000,default=30000
blend = 0.85, --min=0,max=2,default=0.85
density = 1.75, --min=0,max=10,default=1.75
exponent = 0.75, --min=0,max=10,default=0.75
backlit = 0.05, --min=0,max=1,default=0.05
sky = 0.00, --min=-4,max=1,default=0.00
night = 0.00, --min=0,max=1,default=0.00
	
Hue = 220, --min=0,max=360,default=220.00
Saturation = 0.50, --min=0,max=10,default=0.5
Level = 2.50, --min=0,max=10,default=2.50
}


--<br>

-- ▌   NERD MOON   ▐   
-- #
nerd__moon_adjust = {
	
low_Hue = 32, --min=0,max=359,default=32
low_Saturation = 1.2, --min=0,max=10,default=1.60
low_Level = 2, --min=0,max=10,default=3.60

high_Hue = 210, --min=0,max=359,default=210
high_Saturation = 0.25, --min=0,max=10,default=0.30
high_Level = 1.8, --min=0,max=10,default=2.00

mie_Exponent = 15.0, --min=0,max=100,default=15.0
mie_Multi = 1.50, --min=0,max=10,default=1.50

ambient_ratio = 0.50 --min=0,max=10,default=0.50
}

-- ▌   NERD STARS   ▐   
-- #
nerd__stars_adjust = {
	
Saturation = 1.00, --min=0,max=10,default=1.00
Exponent = 0.75, --min=0,max=10,default=1.00
}


--<br>

-- ▌   NERD CSP Lights   ▐   
-- #
nerd__csp_lights_adjust = {

bounced_day = 0.00, --min=0,max=10,default=0.00
bounced_night = 1.00, --min=0,max=10,default=1.00

emissive_day = 0.65, --min=0,max=10,default=0.65
emissive_night = 1.00, --min=0,max=10,default=1.00
}




-- performance presets
--[[

performancepresets = {
    sol__use_cpu_split = ultra --low=true, high=false, ultra=false
    clouds__distance_multiplier = 1.0, --low=1.0, high=1.60, ultra=1.75
    clouds__quality = 0.4  --low=0.4, high=0.80, ultra=1.00
    clouds__render_limiter = 2  --low=2, high=2, ultra=2
    clouds__render_per_frame = 10  --low=5, high=20, ultra=35
}
nightpresets = {
    night__brightness_adjust = 0.3 --low=0.0, high=0.7, ultra=1.0
    night__moonlight_multiplier = 1.0 --low=1.0, high=2.0, ultra=4.0
    night__starlight_multiplier = 1.0 --low=0.5, high=2.0, ultra=4.0
}
firstpage = {
    sol__use_cpu_split,
    clouds__distance_multiplier,
    clouds__quality,
    clouds__render_limiter,
    clouds__render_per_frame,
}
]]
